#ifndef I2C_COMM_H
#define I2C_COMM_H

#include <Arduino.h>

#define ARDUINO_ADDR        8       // Adresse de l'Arduino sur le bus I2C


class I2C_comm {
private:
  uint8_t _cmd;
  int8_t _param1, _param2, _param3;
  uint8_t _id;
  int16_t _value;

public:
  /** Crée un objet bacarComm */
  I2C_comm ();

  /** Initialise la communication avec la Rpi.
   *  Cette fonction doit être appelée dans setup(). */
  void begin(void);

  /** Vérifie si un nouveau message de l'Orange Pi a été reçu.
   *  Si oui, le message est lu et les quatres paramètres du message (x,y,u,v) sont sauvés
   *  dans des champs privés de l'objet.
   *  Retour :
   *    true si un nouveau message a été reçu, false sinon. */
  bool newMessage(void);

  /** Renvoie la valeur du paramètre x du dernier message reçu */
  uint8_t readCmd(void);

  /** Renvoie la valeur du paramètre y du dernier message reçu */
  int8_t readParam1(void);
    
  /** Renvoie la valeur du paramètre u du dernier message reçu */
  int8_t readParam2(void);

  /** Renvoie la valeur du paramètre v du dernier message reçu */
  int8_t readParam3(void);

  /** Envoie un message à l'Orange Pi.
   *  Paramètres :
   *    . */
  void sendMessage(uint8_t id, int16_t value);
};

#endif /* end of include guard #ifndef I2C_COMM_H */
