#include <Wire.h>
#include "I2C_comm.h"

//********************************************************
// Low level functions prototypes
//********************************************************
volatile int cmd[5];
void sendData();
void receiveData(int byteCount);
uint8_t id;
int16_t value;


//********************************************************
// Class implementation
//********************************************************
I2C_comm::I2C_comm(void) {
}

void I2C_comm::begin(void) {
  Wire.begin(ARDUINO_ADDR);                //Set up I2C
  Wire.onReceive(receiveData);
  Wire.onRequest(sendData);
  _cmd = 0;
  _param1 = 0;
  _param2 = 0;
  _param3 = 0;
  cmd[0] = 0;
}

uint8_t I2C_comm::readCmd(void) {
  return(_cmd);
}

int8_t I2C_comm::readParam1(void) {
  return(_param1);
}

int8_t I2C_comm::readParam2(void) {
  return(_param2);
}

int8_t I2C_comm::readParam3(void) {
  return(_param3);
}

bool I2C_comm::newMessage(void) {
  if (cmd[0] != 0) {
    _cmd = cmd[0];
    _param1 = cmd[1];
    _param2 = cmd[2];
    _param3 = cmd[3];
    cmd[0] = 0;
    return (true);
  } else {
    return(false);
  }
}

void I2C_comm::sendMessage(uint8_t newId, int16_t newValue) {
	id = newId;
	value = newValue;
}


//Receive commands via I2C
void receiveData(int byteCount) {  
   static int index = 0;
   
    while(Wire.available()) {
        //When the buffer gets filled up with 4 bytes( the commands have to be 4 bytes in size), set the index back to 0 to read the next command
        if (Wire.available() == 4) {
            index=0;
        }
        cmd[index++] = Wire.read(); //Load the command into the buffer
     }
 }


// callback for sending data
void sendData() {
	Wire.write(id);
	Wire.write(value);
	id = 0;
	value = 0;
}

